import copy
import numpy as np
import torch
from torch import nn
from torch.nn import functional as F
from actions import global_greedy_actions, policy_logits


def as_batch(episodes, key, device, dtype=torch.float32):
    return torch.as_tensor(np.stack([episode[key] for episode in episodes]), device=device, dtype=dtype)


class TDLearner:
    def __init__(self, system, lr=0.0003, reward_scale=10000.0, target_interval=20, grad_clip=10.0):
        self.system = system
        self.target = copy.deepcopy(system)
        self.target.requires_grad_(False)
        self.optimizer = torch.optim.Adam(system.parameters(), lr=lr)
        self.reward_scale = reward_scale
        self.target_interval = target_interval
        self.grad_clip = grad_clip
        self.updates = 0

    def update(self, episodes):
        device = next(self.system.parameters()).device
        observations = as_batch(episodes, 'observations', device)
        actions = as_batch(episodes, 'actions', device, torch.long)
        masks = as_batch(episodes, 'masks', device, torch.bool)
        independent = self.system.algorithm == 'iql'
        if independent:
            rewards = as_batch(episodes, 'local_rewards', device) / self.reward_scale
        else:
            states = as_batch(episodes, 'states', device)
            rewards = as_batch(episodes, 'rewards', device) / self.reward_scale
        online_q = self.system(observations)[:, :-1]
        chosen_q = online_q.gather(-1, actions.unsqueeze(-1)).squeeze(-1)
        with torch.no_grad():
            target_q = self.target(observations)[:, 1:]
            next_masks = masks[:, 1:]
            if independent:
                next_q = target_q.masked_fill(~next_masks, -torch.inf).max(dim=-1).values
                targets = rewards + torch.where(next_masks.any(dim=-1), next_q, 0.0)
            else:
                next_actions, _ = global_greedy_actions(self.target, target_q, next_masks, states[:, 1:])
                next_q = target_q.gather(-1, next_actions.unsqueeze(-1)).squeeze(-1)
                alive = next_masks.flatten(-2).any(dim=-1).float()
                targets = rewards + alive * self.target.mix(next_q, states[:, 1:])
        predicted = chosen_q if independent else self.system.mix(chosen_q, states[:, :-1])
        loss = F.mse_loss(predicted, targets)
        if not torch.isfinite(loss):
            raise FloatingPointError('TD loss is not finite.')
        self.optimizer.zero_grad(set_to_none=True)
        loss.backward()
        if independent:
            for agent in self.system.agents:
                nn.utils.clip_grad_norm_(agent.parameters(), self.grad_clip, error_if_nonfinite=True)
        else:
            nn.utils.clip_grad_norm_(self.system.parameters(), self.grad_clip, error_if_nonfinite=True)
        self.optimizer.step()
        self.updates += 1
        if self.updates % self.target_interval == 0:
            self.synchronize()
        return float(loss.detach())

    def synchronize(self):
        self.target.load_state_dict(self.system.state_dict())


class PPOLearner:
    def __init__(self, system, lr=0.0003, reward_scale=10000.0, epochs=4,
                 clip=0.2, value_coef=0.5, entropy_coef=0.01, grad_clip=1.0):
        self.system = system
        self.optimizer = torch.optim.Adam(system.parameters(), lr=lr)
        self.reward_scale = reward_scale
        self.epochs = epochs
        self.clip = clip
        self.value_coef = value_coef
        self.entropy_coef = entropy_coef
        self.grad_clip = grad_clip

    def update(self, episodes):
        device = next(self.system.parameters()).device
        observations = as_batch(episodes, 'observations', device)[:, :-1]
        states = as_batch(episodes, 'states', device)[:, :-1]
        actions = as_batch(episodes, 'flat_actions', device, torch.long)
        masks = as_batch(episodes, 'masks', device, torch.bool)[:, :-1]
        old_logs = as_batch(episodes, 'old_logs', device)
        rewards = as_batch(episodes, 'rewards', device) / self.reward_scale
        returns = rewards.flip(-1).cumsum(-1).flip(-1)
        with torch.no_grad():
            values = self.system.centralized_critic(states).squeeze(-1)
            advantages = returns - values
            advantages = (advantages - advantages.mean()) / advantages.std(unbiased=False).clamp_min(1e-6)
        for _ in range(self.epochs):
            logits = policy_logits(self.system(observations), masks)
            dist = torch.distributions.Categorical(logits=logits)
            ratio = (dist.log_prob(actions) - old_logs).exp()
            surrogate = torch.minimum(ratio * advantages,
                                      ratio.clamp(1 - self.clip, 1 + self.clip) * advantages)
            values = self.system.centralized_critic(states).squeeze(-1)
            loss = (-surrogate.mean() + self.value_coef * F.mse_loss(values, returns)
                    - self.entropy_coef * dist.entropy().mean())
            if not torch.isfinite(loss):
                raise FloatingPointError('PPO loss is not finite.')
            self.optimizer.zero_grad(set_to_none=True)
            loss.backward()
            nn.utils.clip_grad_norm_(self.system.parameters(), self.grad_clip, error_if_nonfinite=True)
            self.optimizer.step()
        return float(loss.detach())
