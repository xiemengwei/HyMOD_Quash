import json
import math
import re
from collections import Counter
from pathlib import Path
from quantization import precision_bits


class MissingData(ValueError):
    pass


class Data:
    def __init__(self, directory, gpus):
        self.values = {}
        directory = Path(directory)
        if not directory.is_dir():
            raise FileNotFoundError(f'数据目录不存在：{directory}')
        for path in sorted(directory.iterdir()):
            if path.suffix.lower() != '.json':
                continue
            matches = [gpu for gpu in set(gpus) if re.search(
                '(?<![A-Za-z0-9])' + re.escape(gpu) + '(?![A-Za-z0-9])', path.stem, re.I)]
            if len(matches) != 1:
                continue
            gpu = matches[0]
            raw = json.loads(path.read_text(encoding='utf-8-sig'))
            if isinstance(raw, dict) and {'models', 'precisions', 'throughput'} <= raw.keys():
                raw = [raw]
            if isinstance(raw, list):
                for row in raw:
                    if len(row['models']) != len(row['precisions']):
                        raise ValueError(f'model数量与精度数量不同：{path.name}')
                    self._add(gpu, zip(row['models'], row['precisions']), row['throughput'], path)
            elif isinstance(raw, dict):
                pattern = r'(\d+)\s*@\s*([A-Za-z0-9]+)'
                for key, value in raw.items():
                    pairs = re.findall(pattern, key)
                    if pairs and not re.sub(pattern, '', key).strip(' \t\r\n,;'):
                        self._add(gpu, pairs, value, path)
                    elif re.fullmatch(r'\s*\d+(?:[\s,;]+\d+)*\s*', key):
                        raise MissingData(f'{path.name} 的吞吐量未注明精度；model需要写成model@8、model@16或model@32。')
        for gpu in set(gpus):
            if not any(name == gpu for name, _ in self.values):
                raise MissingData(f'数据目录中没有 {gpu} 的含精度吞吐量数据。')

    def _add(self, gpu, pairs, value, path):
        group = tuple(sorted((int(model), precision_bits(bits)) for model, bits in pairs))
        value = float(value)
        if not math.isfinite(value) or value < 0:
            raise ValueError(f'吞吐量不是有效数值：{path.name}，{group}')
        table = self.values.setdefault((gpu, len(group)), {})
        if group in table and table[group] != value:
            raise ValueError(f'同一个GPU上的相同model和精度组合有不同吞吐量：{path.name}，{group}')
        table[group] = value

    def table(self, gpu, size):
        if size == 0:
            return {(): 0.0}
        try:
            return self.values[gpu, size]
        except KeyError:
            raise MissingData(f'缺少 {gpu} 同时运行 {size} 个model的吞吐量数据。') from None

    def partial_score(self, gpus, groups):
        return sum(self.partial_scores(gpus, groups))

    def partial_scores(self, gpus, groups):
        return [self.values.get((gpu, len(group)), {}).get(tuple(sorted(group)), 0.0)
                for gpu, group in zip(gpus, groups)]

    def score(self, scenario, groups):
        deployed = Counter(model for group in groups for model, _ in group)
        if len(groups) != len(scenario.gpus) or deployed != Counter(scenario.models):
            raise ValueError('分配后的model数量或GPU数量不对。')
        if scenario.capacities is not None and list(map(len, groups)) != scenario.capacities:
            raise ValueError('每张GPU上的model数量不对。')
        scores = []
        for gpu, group in zip(scenario.gpus, groups):
            key = tuple(sorted((int(model), precision_bits(bits)) for model, bits in group))
            try:
                scores.append(self.table(gpu, len(group))[key])
            except KeyError:
                raise MissingData(f'缺少 {gpu} 上model和精度组合 {key} 的吞吐量。') from None
        return float(sum(scores)), scores
