from networks import AgentSystem

class IQLSystem(AgentSystem):
    algorithm = 'iql'
