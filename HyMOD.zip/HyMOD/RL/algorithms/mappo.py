from torch import nn
from networks import AgentSystem

class MAPPOSystem(AgentSystem):
    algorithm = 'mappo'

    def __init__(self, agent_count, obs_dim, state_dim, hidden_dim, action_count, critic_hidden=16):
        super().__init__(agent_count, obs_dim, hidden_dim, action_count)
        self.centralized_critic = nn.Sequential(nn.Linear(state_dim, critic_hidden), nn.Tanh(), nn.Linear(critic_hidden, 1))
