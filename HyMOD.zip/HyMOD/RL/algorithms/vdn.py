from networks import AgentSystem

class VDNSystem(AgentSystem):
    algorithm = 'vdn'

    def mix(self, local_q, state):
        return local_q.sum(-1)

    def candidate_values(self, noop_q, best_q, state):
        return noop_q.sum(-1, keepdim=True) + best_q - noop_q
