def make_system(algorithm, agent_count, obs_dim, state_dim, action_count, args):
    if algorithm == 'hymod':
        from .hymod import HyMODSystem
        return HyMODSystem(agent_count, obs_dim, state_dim, args.hymod_hidden, action_count, args.hymod_hidden, 1.0, args.hymod_activations)
    if algorithm == 'qmix':
        from .qmix import QMIXSystem
        return QMIXSystem(agent_count, obs_dim, state_dim, args.hidden, action_count, args.mixing_hidden)
    if algorithm == 'vdn':
        from .vdn import VDNSystem
        return VDNSystem(agent_count, obs_dim, args.hidden, action_count)
    if algorithm == 'iql':
        from .iql import IQLSystem
        return IQLSystem(agent_count, obs_dim, args.hidden, action_count)
    if algorithm == 'mappo':
        from .mappo import MAPPOSystem
        return MAPPOSystem(agent_count, obs_dim, state_dim, 16, action_count, 16)
    raise ValueError(f'Unknown algorithm: {algorithm}')
