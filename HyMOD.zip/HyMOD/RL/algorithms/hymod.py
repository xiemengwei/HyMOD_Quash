import math
import torch
from torch import nn
from torch.nn import functional as F
from networks import AgentSystem
ACTIVATIONS = ('prelu', 'tanh', 'leakyrelu', 'elu', 'relu', 'silu')

def activation(name):
    factories = dict(prelu=nn.PReLU, tanh=nn.Tanh, leakyrelu=lambda: nn.LeakyReLU(0.01), elu=nn.ELU, relu=nn.ReLU, silu=nn.SiLU)
    if name not in factories:
        raise ValueError(f'Unknown HHN activation: {name}')
    return factories[name]()

class HybridHypernetwork(nn.Module):

    def __init__(self, state_dim, agent_count, hidden_dim, activations):
        super().__init__()
        self.agent_count = agent_count
        names = activations.split(',') if isinstance(activations, str) else list(activations)
        names = [name.strip().lower() for name in names]
        if len(names) == 1:
            names *= 4
        if len(names) != 4:
            raise ValueError('Supply four activations in w1,b1,wfinal,bfinal order.')
        self.activation_names = tuple(names)

        def head(output_dim, name):
            return nn.Sequential(nn.Linear(state_dim, hidden_dim), activation(name), nn.Linear(hidden_dim, output_dim))
        self.weight_in = head(1, names[0])
        self.bias_in = head(1, names[1])
        self.weight_out = head(1, names[2])
        self.bias_out = head(1, names[3])

    def forward(self, state):
        return (F.softplus(self.weight_in(state)) + 1e-4, self.bias_in(state),
                F.softplus(self.weight_out(state)) + 1e-4, self.bias_out(state))

class HyMOD_mixingnet(nn.Module):

    def __init__(self, state_dim, agent_count, hidden_dim=32, beta=1.0, activations='prelu,tanh,leakyrelu,elu'):
        super().__init__()
        if not math.isfinite(beta) or beta <= 0:
            raise ValueError('LSE beta must be finite and positive.')
        self.beta = beta
        self.agent_count = agent_count
        self.hybrid_hypernetwork = HybridHypernetwork(state_dim, agent_count, hidden_dim, activations)

    def forward(self, local_q, state):
        w1, b1, wfinal, bfinal = self.hybrid_hypernetwork(state)
        weights_in = torch.diag_embed(w1.expand(*state.shape[:-1], self.agent_count))
        hidden_logits = self.beta * (torch.matmul(local_q.unsqueeze(-2), weights_in).squeeze(-2) + b1)
        return torch.logsumexp(hidden_logits + wfinal.log(), dim=-1) / self.beta + bfinal.squeeze(-1)

    def effective_parameters(self, state):
        w1, b1, wfinal, bfinal = self.hybrid_hypernetwork(state)
        shape = (*state.shape[:-1], self.agent_count)
        return w1.expand(shape), (b1 + wfinal.log() / self.beta + bfinal).expand(shape)

    def candidate_values(self, noop_q, best_q, state):
        weights, biases = self.effective_parameters(state)
        baseline = weights * noop_q + biases
        candidates = baseline.unsqueeze(-2) + torch.diag_embed(weights * (best_q - noop_q))
        return torch.logsumexp(self.beta * candidates, dim=-1) / self.beta

class HyMODSystem(AgentSystem):
    algorithm = 'hymod'

    def __init__(self, agent_count, obs_dim, state_dim, hidden_dim, action_count, mixing_hidden=32, beta=1.0, activations='prelu,tanh,leakyrelu,elu'):
        super().__init__(agent_count, obs_dim, hidden_dim, action_count - 1)
        self.hymod_mixingnet = HyMOD_mixingnet(state_dim, agent_count, mixing_hidden, beta, activations)

    def forward(self, observations):
        values = super().forward(observations)
        return torch.cat([values, torch.zeros_like(values[..., :1])], dim=-1)

    def step(self, observations, hidden=None, weights=None):
        values, hidden = super().step(observations, hidden, weights)
        return torch.cat([values, torch.zeros_like(values[..., :1])], dim=-1), hidden

    def mix(self, local_q, state):
        return self.hymod_mixingnet(local_q, state)

    def candidate_values(self, noop_q, best_q, state):
        return self.hymod_mixingnet.candidate_values(noop_q, best_q, state)
