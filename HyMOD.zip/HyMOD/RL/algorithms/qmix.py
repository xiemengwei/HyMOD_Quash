import torch
from torch import nn
from torch.nn import functional as F
from networks import AgentSystem

class QMIXMixingNet(nn.Module):

    def __init__(self, state_dim, agent_count, mixing_hidden=32):
        super().__init__()
        self.agent_count = agent_count
        self.mixing_hidden = mixing_hidden
        self.hyper_weight_in = nn.Linear(state_dim, agent_count * mixing_hidden)
        self.hyper_bias_in = nn.Linear(state_dim, mixing_hidden)
        self.hyper_weight_out = nn.Linear(state_dim, mixing_hidden)
        self.hyper_bias_out = nn.Sequential(nn.Linear(state_dim, mixing_hidden), nn.ReLU(),
                                            nn.Linear(mixing_hidden, 1))

    def parameters_for(self, state):
        shape = state.shape[:-1]
        weights_in = self.hyper_weight_in(state).abs().reshape(*shape, self.agent_count, self.mixing_hidden)
        bias_in = self.hyper_bias_in(state)
        weights_out = self.hyper_weight_out(state).abs()
        bias_out = self.hyper_bias_out(state).squeeze(-1)
        return weights_in, bias_in, weights_out, bias_out

    def forward(self, local_q, state):
        weights_in, bias_in, weights_out, bias_out = self.parameters_for(state)
        hidden = F.elu(torch.matmul(local_q.unsqueeze(-2), weights_in).squeeze(-2) + bias_in)
        return (hidden * weights_out).sum(dim=-1) + bias_out

    def candidate_values(self, noop_q, best_q, state):
        weights_in, bias_in, weights_out, bias_out = self.parameters_for(state)
        baseline = torch.matmul(noop_q.unsqueeze(-2), weights_in).squeeze(-2) + bias_in
        hidden = F.elu(baseline.unsqueeze(-2) + (best_q - noop_q).unsqueeze(-1) * weights_in)
        return (hidden * weights_out.unsqueeze(-2)).sum(dim=-1) + bias_out.unsqueeze(-1)

class QMIXSystem(AgentSystem):
    algorithm = 'qmix'

    def __init__(self, agent_count, obs_dim, state_dim, hidden_dim, action_count, mixing_hidden=32):
        super().__init__(agent_count, obs_dim, hidden_dim, action_count)
        self.qmix_mixingnet = QMIXMixingNet(state_dim, agent_count, mixing_hidden)

    def mix(self, local_q, state):
        return self.qmix_mixingnet(local_q, state)

    def candidate_values(self, noop_q, best_q, state):
        return self.qmix_mixingnet.candidate_values(noop_q, best_q, state)
