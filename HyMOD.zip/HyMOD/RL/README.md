运行五个算法：

```bash
python train.py --scenario 5x3 --data-dir "Data_Dir" --accuracy-data "Accuracy_File" --accuracy-threshold 0.1 --episodes 4500 --device cuda:0
```

| 场景    | GPU 和 model 数量                       |
| ----- | ------------------------------------ |
| 5x3   | 5 个 GPU，每张 GPU 容纳 3 个 model，共 15 个   |
| 5x4   | 5 个 GPU，每张 GPU 容纳 4 个 model，共 20 个   |
| 5x5   | 5 个 GPU，每张 GPU 容纳 5 个 model，共 25 个   |
| 6x5   | 6 个 GPU，每张 GPU 容纳 5 个 model，共 30 个   |
| 8gpus | 8 个 GPU，每张 GPU 容纳 model 数量不固定，总数为 30 |
| 10x3  | 10 个 GPU，每张 GPU 容纳 3 个 model，共 30 个  |

--scenario all 运行六个场景。--algorithm hymod 只运行 HyMOD；也可选 qmix、mappo、vdn、iql。

激活函数可用 `--hymod-activations relu` 更改，默认是 `prelu,tanh,leakyrelu,elu`。



因为难以提供在线实测环境，所以数据使用离线的数据。不同量化位数的精度损失需要外部输入。代码没有显式检查论文中的剩余显存和算力容量，没有提供实测数据。
