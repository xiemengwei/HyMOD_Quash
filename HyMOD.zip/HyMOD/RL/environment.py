import numpy as np
from quantization import PRECISIONS, precision_bits


class Environment:
    def __init__(self, scenario, data, accuracy):
        self.layout = scenario
        self.data = data
        self.n = len(scenario.gpus)
        self.model_types = scenario.model_types
        self.model_index = {model: i for i, model in enumerate(self.model_types)}
        self.model_count = len(self.model_types)
        self.steps = len(scenario.models)
        self.noop = len(PRECISIONS) * self.model_count
        self.action_count = self.noop + 1
        self.capacities = np.asarray(scenario.capacities if scenario.capacities is not None
                                     else [self.steps] * self.n, dtype=np.int64)
        accuracy.require_models(self.model_types)
        self.accuracy_mask = np.asarray(
            [accuracy.allowed(model, bits) for bits in PRECISIONS for model in self.model_types],
            dtype=bool)
        self.reset()

    def reset(self):
        self.placements = np.zeros((self.n, self.noop), dtype=np.float32)
        self.remaining = np.ones(self.model_count, dtype=bool)
        self.groups = [[] for _ in range(self.n)]
        self.deployed = np.zeros(self.n, dtype=np.int64)
        self.time = 0
        self.potential = 0.0
        self.throughput = 0.0
        self.gpu_scores = np.zeros(self.n, dtype=np.float64)
        self.local_rewards = np.zeros(self.n, dtype=np.float64)
        return self.state()

    def encode_action(self, model, precision):
        return PRECISIONS.index(precision_bits(precision)) * self.model_count + self.model_index[model]

    def decode_action(self, action):
        if not 0 <= action < self.noop:
            raise ValueError(f'部署动作编号超出范围：{action}')
        return self.model_types[action % self.model_count], PRECISIONS[action // self.model_count]

    def mask(self):
        mask = np.zeros((self.n, self.action_count), dtype=bool)
        available = np.tile(self.remaining, len(PRECISIONS)) & self.accuracy_mask
        mask[:, :self.noop] = (self.deployed < self.capacities)[:, None] & available[None, :]
        return mask

    def state(self):
        free = (self.capacities - self.deployed) / self.capacities
        progress = self.time / self.steps
        observations = np.concatenate([
            self.placements,
            np.broadcast_to(self.remaining, (self.n, self.model_count)),
            np.eye(self.n, dtype=np.float32),
            free[:, None],
            np.full((self.n, 1), progress)
        ], axis=1)
        state = np.concatenate([
            self.placements.ravel(), self.remaining, free, [progress]
        ])
        return observations.astype(np.float32), state.astype(np.float32)

    def step(self, action):
        gpu, local_action = divmod(int(action), self.action_count)
        mask = self.mask()
        if not 0 <= gpu < self.n or not 0 <= local_action < self.noop or not mask[gpu, local_action]:
            raise ValueError('当前动作不能部署：model已部署、GPU已满或精度不满足阈值。')
        model, bits = self.decode_action(local_action)
        self.groups[gpu].append((model, bits))
        self.placements[gpu, local_action] = 1.0
        self.remaining[self.model_index[model]] = False
        self.deployed[gpu] += 1
        self.time += 1
        done = self.time == self.steps
        if done:
            self.throughput, scores = self.data.score(self.layout, self.groups)
            value = self.throughput
        else:
            scores = self.data.partial_scores(self.layout.gpus, self.groups)
            value = sum(scores)
        scores = np.asarray(scores, dtype=np.float64)
        self.local_rewards = scores - self.gpu_scores
        self.gpu_scores = scores
        reward = value - self.potential
        self.potential = value
        return reward, done
