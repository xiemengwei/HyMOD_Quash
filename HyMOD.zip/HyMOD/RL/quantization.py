import json
import math
from pathlib import Path
import numpy as np

PRECISIONS = (8, 16, 32)


def precision_bits(value):
    text = str(value).strip().upper()
    names = {'INT8': 8, 'FP16': 16, 'FP32': 32, '8': 8, '16': 16, '32': 32}
    if text not in names:
        raise ValueError(f'量化精度需要为8、16或32：{value}')
    return names[text]


class Accuracy:
    def __init__(self, path, threshold):
        self.threshold = float(threshold)
        if not math.isfinite(self.threshold) or self.threshold < 0:
            raise ValueError('accuracy threshold需要是非负数。')
        self.losses = {}
        path = Path(path)
        if path.suffix.lower() == '.json':
            rows = json.loads(path.read_text(encoding='utf-8-sig'))
            for model, losses in rows.items():
                self._add(int(model), {precision_bits(bits): float(loss) for bits, loss in losses.items()})
        else:
            lines = [line for line in path.read_text(encoding='utf-8-sig').splitlines()
                     if line.strip() and not line.lstrip().startswith('#')]
            if not lines:
                raise ValueError('accuracy损失文件为空。')
            delimiter = ',' if ',' in lines[0] else None
            first = lines[0].replace(',', ' ').split()[0].lower()
            if first in ('model', 'model_id'):
                lines = lines[1:]
            rows = np.loadtxt(lines, delimiter=delimiter, ndmin=2)
            if rows.shape[1] != 4:
                raise ValueError('accuracy损失数据每行需要四列：model、loss8、loss16、loss32。')
            for row in rows:
                if not math.isfinite(row[0]) or row[0] != int(row[0]):
                    raise ValueError('accuracy损失数据中的model编号需要是整数。')
                self._add(int(row[0]), dict(zip(PRECISIONS, row[1:])))

    def _add(self, model, losses):
        if set(losses) != set(PRECISIONS) or not all(math.isfinite(x) for x in losses.values()):
            raise ValueError(f'model {model} 需要提供8、16、32位的有效accuracy损失。')
        if model in self.losses and self.losses[model] != losses:
            raise ValueError(f'model {model} 存在不同的accuracy损失记录。')
        self.losses[model] = losses

    def allowed(self, model, precision):
        return self.losses[model][precision] <= self.threshold

    def require_models(self, models):
        for model in models:
            if model not in self.losses:
                raise ValueError(f'缺少model {model} 的accuracy损失。')
            if not any(self.allowed(model, bits) for bits in PRECISIONS):
                raise ValueError(f'model {model} 的三种精度都超过accuracy损失阈值。')
