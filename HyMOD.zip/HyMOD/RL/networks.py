import torch
from torch import nn
from torch.nn import functional as F

class LocalDRQN(nn.Module):

    def __init__(self, observation_dim, hidden_dim, action_count):
        super().__init__()
        self.embedding = nn.Linear(observation_dim, hidden_dim)
        self.gru = nn.GRU(hidden_dim, hidden_dim, batch_first=True)
        self.head = nn.Linear(hidden_dim, action_count)

    def forward(self, observations):
        encoded = F.relu(self.embedding(observations))
        hidden, _ = self.gru(encoded)
        return self.head(hidden)

class AgentSystem(nn.Module):

    def __init__(self, agent_count, observation_dim, hidden_dim, action_count):
        super().__init__()
        self.agents = nn.ModuleList([LocalDRQN(observation_dim, hidden_dim, action_count) for _ in range(agent_count)])

    def forward(self, observations):
        return torch.stack([agent(observations[:, :, i]) for i, agent in enumerate(self.agents)], dim=2)

    def step_weights(self):
        return tuple(torch.stack(values) for values in zip(*[
            (agent.embedding.weight, agent.embedding.bias,
             agent.gru.weight_ih_l0, agent.gru.bias_ih_l0,
             agent.gru.weight_hh_l0, agent.gru.bias_hh_l0,
             agent.head.weight, agent.head.bias)
            for agent in self.agents
        ]))

    def step(self, observations, hidden=None, weights=None):
        if weights is None:
            weights = self.step_weights()
        embed_w, embed_b, input_w, input_b, hidden_w, hidden_b, head_w, head_b = weights
        encoded = F.relu(torch.bmm(observations.transpose(0, 1), embed_w.transpose(1, 2))
                         + embed_b[:, None, :])
        if hidden is None:
            hidden = torch.zeros_like(encoded)
        input_gates = torch.bmm(encoded, input_w.transpose(1, 2)) + input_b[:, None, :]
        hidden_gates = torch.bmm(hidden, hidden_w.transpose(1, 2)) + hidden_b[:, None, :]
        i_reset, i_update, i_new = input_gates.chunk(3, dim=-1)
        h_reset, h_update, h_new = hidden_gates.chunk(3, dim=-1)
        reset = torch.sigmoid(i_reset + h_reset)
        update = torch.sigmoid(i_update + h_update)
        new = torch.tanh(i_new + reset * h_new)
        hidden = new + update * (hidden - new)
        values = torch.bmm(hidden, head_w.transpose(1, 2)) + head_b[:, None, :]
        return values.transpose(0, 1), hidden
