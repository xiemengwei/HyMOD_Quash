import numpy as np
import torch


def greedy_actions(system, local_q, mask, state):
    if system.algorithm in ('hymod', 'iql'):
        action_count = local_q.shape[-1]
        flat = local_q.masked_fill(~mask, -torch.inf).flatten(-2).argmax(dim=-1)
        joint = torch.full_like(local_q[..., 0], action_count - 1, dtype=torch.long)
        joint.scatter_(-1, (flat // action_count).unsqueeze(-1), (flat % action_count).unsqueeze(-1))
        alive = mask.flatten(-2).any(dim=-1)
        return torch.where(alive.unsqueeze(-1), joint, action_count - 1), flat
    return global_greedy_actions(system, local_q, mask, state)


def global_greedy_actions(system, local_q, mask, state):
    action_count = local_q.shape[-1]
    noop = action_count - 1
    best_actions = local_q.masked_fill(~mask, -torch.inf).argmax(dim=-1)
    best_q = local_q.gather(-1, best_actions.unsqueeze(-1)).squeeze(-1)
    values = system.candidate_values(local_q[..., noop], best_q, state)
    gpu = values.masked_fill(~mask.any(dim=-1), -torch.inf).argmax(dim=-1)
    action = best_actions.gather(-1, gpu.unsqueeze(-1)).squeeze(-1)
    flat = gpu * action_count + action
    joint = torch.full_like(local_q[..., 0], noop, dtype=torch.long)
    joint.scatter_(-1, gpu.unsqueeze(-1), action.unsqueeze(-1))
    alive = mask.flatten(-2).any(dim=-1)
    joint = torch.where(alive.unsqueeze(-1), joint, noop)
    return joint, flat


def policy_logits(scores, mask):
    logits = scores - scores[..., -1:]
    return logits.masked_fill(~mask, -torch.inf).flatten(-2)


@torch.no_grad()
def rollout(system, env, rng, epsilon=0.0, deterministic=False):
    obs, state = env.reset()
    observations, states, masks = [obs], [state], [env.mask()]
    actions, flat_actions, old_logs, rewards, local_rewards = [], [], [], [], []
    device = next(system.parameters()).device
    hidden = None
    weights = system.step_weights()
    for _ in range(env.steps):
        scores, hidden = system.step(torch.as_tensor(obs[None], device=device), hidden, weights)
        scores = scores[0]
        mask = torch.as_tensor(masks[-1], device=device)
        if system.algorithm == 'mappo':
            dist = torch.distributions.Categorical(logits=policy_logits(scores, mask))
            chosen = dist.logits.argmax() if deterministic else dist.sample()
            flat = int(chosen)
            logp = float(dist.log_prob(chosen))
        else:
            if not deterministic and rng.random() < epsilon:
                flat = int(rng.choice(np.flatnonzero(masks[-1])))
            else:
                _, selected = greedy_actions(system, scores, mask, torch.as_tensor(state, device=device))
                flat = int(selected)
            logp = 0.0
        gpu, action = divmod(flat, env.action_count)
        joint = np.full(env.n, env.noop, dtype=np.int64)
        joint[gpu] = action
        reward, done = env.step(flat)
        actions.append(joint)
        flat_actions.append(flat)
        old_logs.append(logp)
        rewards.append(reward)
        local_rewards.append(env.local_rewards.copy())
        obs, state = env.state()
        observations.append(obs)
        states.append(state)
        masks.append(env.mask())
        if done:
            break
    return dict(observations=np.asarray(observations), states=np.asarray(states),
                actions=np.asarray(actions), flat_actions=np.asarray(flat_actions),
                masks=np.asarray(masks), old_logs=np.asarray(old_logs, dtype=np.float32),
                rewards=np.asarray(rewards, dtype=np.float32),
                local_rewards=np.asarray(local_rewards, dtype=np.float32), throughput=env.throughput)
