function fig = plot_fig08_09_inference_latency(files, methods, titles, varargin)
if nargin < 2 || isempty(methods)
    methods = {'IQL-based','VDN-based','QMIX-based','MAPPO-based','HyMOD'};
end
if nargin < 1
    files = choose_txt(methods);
end
if nargin < 3
    titles = {};
end
fig = plot_curves(files, methods, titles, 'Inference latency (s)', varargin{:});
end
