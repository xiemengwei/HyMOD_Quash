function fig = plot_fig10_learning_latency(files, categories, methods, titles, varargin)
if nargin < 1
    files = choose_txt({'data'});
end
if nargin < 2
    categories = {};
end
if nargin < 3
    methods = {};
end
if nargin < 4
    titles = {};
end
fig = plot_bars(files, categories, methods, titles, 'Learning latency (s)', varargin{:});
end
