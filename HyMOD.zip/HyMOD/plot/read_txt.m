function values = read_txt(filename, column)
if nargin < 2
    column = [];
end
if exist('readmatrix', 'file')
    values = readmatrix(filename);
else
    values = dlmread(filename);
end
if isempty(values)
    error('TXT没有数据。');
end
if ~isempty(column)
    values = values(:, column);
elseif isvector(values)
    values = values(:);
end
if any(~isfinite(values(:)))
    error('TXT里有非数值内容。');
end
end
