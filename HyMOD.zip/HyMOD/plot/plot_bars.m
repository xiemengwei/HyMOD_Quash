function figs = plot_bars(files, categories, methods, titles, yLabels, varargin)
if ischar(files)
    files = {files};
elseif isstring(files)
    files = cellstr(files);
end
figs = gobjects(numel(files),1);
for panel = 1:numel(files)
    values = read_txt(files{panel});
    if isvector(values) && ~isempty(methods) && numel(methods) == numel(values)
        values = reshape(values,1,[]);
    end
    names = methods;
    if isempty(names)
        names = arrayfun(@num2str, 1:size(values,2), 'UniformOutput', false);
    end
    if numel(names) ~= size(values,2)
        error('每种方法对应TXT的一列。');
    end
    labels = categories;
    if isempty(labels)
        labels = arrayfun(@num2str, 1:size(values,1), 'UniformOutput', false);
    elseif iscell(labels) && iscell(labels{1})
        labels = labels{panel};
    end
    order = method_order(names);
    names = names(order);
    values = values(:,order);
    colors = method_colors(names);
    figs(panel) = figure;
    if ~isempty(titles)
        set(figs(panel), 'Name', titles{panel}, 'NumberTitle', 'off');
    end
    if size(values,1) == 1
        barObj = bar(1, values, 'BarWidth', 1.0);
    else
        barObj = bar(values, 'BarWidth', 1.0);
    end
    for i = 1:numel(barObj)
        barObj(i).FaceColor = colors(i,:);
        barObj(i).FaceAlpha = 0.9;
    end
    legend(barObj, names, 'Location', 'northwest', 'FontSize', 15, ...
        'FontName', 'Times New Roman', 'NumColumns', 2);
    xlabel('', 'FontSize', 20, 'FontName', 'Times New Roman');
    label = yLabels;
    if iscell(yLabels)
        label = yLabels{panel};
    end
    ylabel(label, 'FontSize', 20, 'FontName', 'Times New Roman');
    if panel == 1
        set(gca,'XTick',1:size(values,1),'XTickLabel',labels,'FontSize',20,'FontName','Times New Roman');
        set(gca,'YLim',[0 13500]);
    else
        set(gca,'XTick',1:size(values,1),'XTickLabel',labels,'FontSize',19,'FontName','Times New Roman');
        set(gca,'YLim',[0 21700]);
    end
    ax = gca;
    ax.XGrid = 'on'; ax.YGrid = 'on';
    ax.GridLineStyle = '-';
    ax.XMinorGrid = 'on'; ax.YMinorGrid = 'on';
    ax.YAxis.Exponent = 3;
    grid on;
    ax.YAxis.Exponent = 3;
    ysecondarylabel(ax, '\times10^{3}');
    ysecondarylabel(ax, 'Visible', 'on');
    drawnow;
    set(figs(panel), 'Units', 'inches');
end
end
