function order = method_order(methods)
keys = cellfun(@(name) regexprep(lower(char(name)), '[^a-z]', ''), methods, 'UniformOutput', false);
keys = cellfun(@(name) regexprep(name, 'based$', ''), keys, 'UniformOutput', false);
reference = {'random','greedy','iql','vdn','qmix','mappo','localsearch','quantizationfirst','placementfirst'};
ranks = 20 + (1:numel(methods));
for i = 1:numel(reference)
    ranks(strcmp(keys,reference{i})) = i;
end
ranks(strcmp(keys,'hymod')) = 100;
[~,order] = sort(ranks);
end
