function fig = plot_fig11_hhn_ablation(throughputFile, latencyFile, categories, methods, varargin)
if nargin < 2
    files = choose_txt({'Throughput','Latency'});
    if isempty(files)
        fig = [];
        return;
    end
    throughputFile = files{1};
    latencyFile = files{2};
end
if nargin < 3
    categories = {};
end
if nargin < 4
    methods = {};
end
fig = plot_bars({throughputFile,latencyFile}, categories, methods, {'Throughput','Inference latency'}, {'Throughput (req/s)','Inference latency (s)'}, varargin{:});
end
