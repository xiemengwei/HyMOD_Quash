function files = choose_txt(methods)
files = cell(1, numel(methods));
for k = 1:numel(methods)
    [name, folder] = uigetfile('*.txt', ['选择 ', methods{k}, ' 的TXT']);
    if isequal(name, 0)
        files = {};
        return;
    end
    files{k} = fullfile(folder, name);
end
end
