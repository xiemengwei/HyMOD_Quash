function fig = plot_fig05_06_convergence(files, methods, titles, varargin)
if nargin < 2 || isempty(methods)
    methods = {'IQL-based','VDN-based','QMIX-based','MAPPO-based','HyMOD'};
end
if nargin < 1
    files = choose_txt(methods);
end
if nargin < 3
    titles = {};
end
fig = plot_curves(files, methods, titles, 'Throughput (images/s)', varargin{:});
end
