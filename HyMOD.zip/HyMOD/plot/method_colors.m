function colors = method_colors(methods)
names = {'random','greedy','iql','vdn','qmix','mappo','localsearch','quantizationfirst','placementfirst','hymod'};
palette = [47 82 143; 197 90 17; 46 117 182; 191 144 0; 123 63 162; ...
    84 130 53; 38 137 145; 119 142 179; 191 122 157; 197 42 32] / 255;
fallback = palette([3 4 5 6 10 1 2 7 8 9],:);
colors = zeros(numel(methods),3);
for i = 1:numel(methods)
    name = regexprep(lower(char(methods{i})), '[^a-z]', '');
    name = regexprep(name, 'based$', '');
    index = find(strcmp(name, names),1);
    if isempty(index)
        colors(i,:) = fallback(mod(i-1,size(fallback,1))+1,:);
    else
        colors(i,:) = palette(index,:);
    end
end
end
