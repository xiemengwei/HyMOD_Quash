function figs = plot_curves(files, methods, titles, yLabels, varargin)
p = inputParser;
addParameter(p, 'ValueColumn', []);
parse(p, varargin{:});
opt = p.Results;
block_size = 20;
new_window = 20;
if ischar(files)
    files = {files};
elseif isstring(files)
    files = cellstr(files);
end
if isvector(files) && numel(methods) ~= 1
    files = reshape(files, 1, []);
end
if isempty(files)
    figs = gobjects(0);
    return;
end
if isempty(methods)
    methods = arrayfun(@num2str, 1:size(files,2), 'UniformOutput', false);
end
if numel(methods) ~= size(files,2)
    error('每种方法对应一个TXT文件。');
end
order = method_order(methods);
methods = methods(order);
files = files(:,order);
colors = method_colors(methods);
figs = gobjects(size(files,1), 1);
for panel = 1:size(files,1)
    x = cell(1, size(files,2));
    smooth_data = cell(size(x));
    std_data = cell(size(x));
    last_episode = 0;
    for i = 1:size(files,2)
        values = read_txt(files{panel,i}, opt.ValueColumn);
        if ~isvector(values)
            error('多列TXT请用ValueColumn选择数值列。');
        end
        values = values(:);
        valid_len = floor(numel(values)/block_size)*block_size;
        if valid_len == 0
            error('TXT至少需要20轮数据。');
        end
        trimmed = values(1:valid_len);
        reshaped = reshape(trimmed,block_size,[]);
        downsampled = mean(reshaped,1)';
        x{i} = (1:numel(downsampled))' * block_size;
        smooth_data{i} = movmean(downsampled,new_window);
        std_data{i} = movstd(downsampled,new_window);
        episodes = (1:numel(values))';
        last_episode = max(last_episode, max(episodes));
    end
    figs(panel) = figure('Units','normalized','Position',[0.1 0.1 0.8 0.7]);
    if ~isempty(titles)
        set(figs(panel), 'Name', titles{panel}, 'NumberTitle', 'off');
    end
    hold on;
    tp_min = inf; tp_max = -inf;
    for i = 1:numel(methods)
        if numel(x{i}) > 1
            x_fill = [x{i}; flipud(x{i})];
            y_fill = [smooth_data{i}+std_data{i}; flipud(smooth_data{i}-std_data{i})];
            fill(x_fill, y_fill, colors(i,:), 'FaceAlpha', 0.2, 'EdgeColor','none');
        end
        spread = std_data{i};
        tp_min = min(tp_min, min(smooth_data{i}-spread));
        tp_max = max(tp_max, max(smooth_data{i}+spread));
    end
    h1 = gobjects(numel(methods),1);
    for i = 1:numel(methods)
        h1(i) = plot(x{i}, smooth_data{i}, 'LineWidth', 3, 'Color', colors(i,:));
        if numel(x{i}) == 1
            set(h1(i), 'Marker', 'o');
        end
    end
    set(gca, 'FontSize', 25, 'FontName', 'Times New Roman', 'LineWidth', 1, 'Box', 'on');
    xlabel('# of episodes', 'FontSize', 30, 'FontName', 'Times New Roman');
    label = yLabels;
    if iscell(yLabels)
        label = yLabels{panel};
    end
    ylabel(label, 'FontSize', 30, 'FontName', 'Times New Roman');
    xlim([0, max(last_episode,1)]);
    tp_range = max([tp_max-tp_min, abs(tp_max)*0.01, 1]);
    ylim([tp_min-tp_range*0.1, tp_max+tp_range*0.35]);
    set(gca, 'XTick', 0:500:last_episode);
    legend(h1, methods, 'Location', 'northwest', 'FontSize', 18, 'FontName', 'Times New Roman', ...
        'EdgeColor', [0 0 0], 'LineWidth', 1, 'Box', 'on');
    ax = gca;
    ax.XGrid = 'on'; ax.YGrid = 'on';
    ax.GridLineStyle = '-';
    ax.XMinorGrid = 'on'; ax.YMinorGrid = 'on';
    ax.YAxis.Exponent = 2;
    set(gca, 'GridAlpha', 0.3, 'MinorGridAlpha', 0.15);
    hold off;
    set(figs(panel), 'Units', 'inches');
end
end
